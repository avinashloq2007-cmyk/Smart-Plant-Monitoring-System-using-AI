"""
generate_sample_data.py
========================
Creates synthetic leaf images in dataset/<ClassName>/ so the training
pipeline can be tested without a real dataset.

Each class gets a distinctive dominant colour + random noise so that
classifiers can actually learn something meaningful from the samples.

IMPORTANT: Replace with real PlantVillage images for production use.
"""

import os
import cv2
import numpy as np


# ─── Configuration ────────────────────────────────────────────────────────────
DATASET_DIR = os.path.join(os.path.dirname(__file__), "dataset")

CLASSES = {
    # class_name : (B, G, R) dominant colour for the synthetic image
    "Healthy":      (34,  139, 34),    # forest green
    "Early_Blight": (80,  100, 150),   # brownish-blue (simulates blight spots)
    "Late_Blight":  (60,   60, 120),   # dark brownish
}

NUM_SAMPLES_PER_CLASS = 60   # per class; increase for better training
IMAGE_SIZE = (64, 64)
NOISE_STD  = 30              # standard deviation of Gaussian noise


def generate_leaf_image(base_color: tuple, seed: int) -> np.ndarray:
    """
    Generate a synthetic leaf image:
      - solid background of `base_color`
      - elliptical "leaf" patch in a slightly different shade
      - Gaussian noise for texture variation
    """
    rng = np.random.default_rng(seed)
    img = np.full((IMAGE_SIZE[1], IMAGE_SIZE[0], 3), base_color, dtype=np.float32)

    # Draw a leaf-like ellipse in the centre
    leaf_color = tuple(max(0, c + int(rng.integers(-40, 40))) for c in base_color)
    cv2.ellipse(img.astype(np.uint8),   # temporary uint8 view
                center=(32, 32),
                axes=(20 + int(rng.integers(-5, 5)), 25 + int(rng.integers(-5, 5))),
                angle=int(rng.integers(0, 360)),
                startAngle=0, endAngle=360,
                color=leaf_color, thickness=-1)

    # Redraw on the float32 array so noise is applied correctly
    cv2.ellipse(img,
                center=(32, 32),
                axes=(20 + int(rng.integers(-5, 5)), 25 + int(rng.integers(-5, 5))),
                angle=int(rng.integers(0, 360)),
                startAngle=0, endAngle=360,
                color=leaf_color, thickness=-1)

    # Gaussian noise
    noise = rng.normal(0, NOISE_STD, img.shape).astype(np.float32)
    img = np.clip(img + noise, 0, 255).astype(np.uint8)

    return img


def main():
    print("Generating synthetic dataset ...\n")
    total = 0

    for class_name, base_color in CLASSES.items():
        class_dir = os.path.join(DATASET_DIR, class_name)
        os.makedirs(class_dir, exist_ok=True)

        for i in range(NUM_SAMPLES_PER_CLASS):
            img  = generate_leaf_image(base_color, seed=i * 100 + hash(class_name) % 1000)
            path = os.path.join(class_dir, f"sample_{i:03d}.jpg")
            cv2.imwrite(path, img)
            total += 1

        print(f"  [{class_name}]  {NUM_SAMPLES_PER_CLASS} images -> {class_dir}")

    print(f"\n[OK] Generated {total} synthetic images across {len(CLASSES)} classes.")
    print("  Replace these with real leaf images for production accuracy.\n")


if __name__ == "__main__":
    main()
