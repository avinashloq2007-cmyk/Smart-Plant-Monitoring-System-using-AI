/**
 * main.js — PlantGuard AI
 * Handles: drag-and-drop, image preview, form submission with progress indicator
 */

(function () {
  "use strict";

  // ── Element refs ──────────────────────────────────────────────
  const dropZone    = document.getElementById("drop-zone");
  const fileInput   = document.getElementById("file-input");
  const previewArea = document.getElementById("preview-area");
  const previewImg  = document.getElementById("preview-img");
  const fileNameEl  = document.getElementById("file-name");
  const clearBtn    = document.getElementById("clear-btn");
  const submitBtn   = document.getElementById("submit-btn");
  const progressWrap= document.getElementById("progress-wrap");
  const form        = document.getElementById("upload-form");

  if (!dropZone) return;   // not on upload page

  // ── Drag-and-drop events ──────────────────────────────────────
  ["dragenter", "dragover"].forEach(evt =>
    dropZone.addEventListener(evt, e => {
      e.preventDefault();
      dropZone.classList.add("drag-over");
    })
  );

  ["dragleave", "drop"].forEach(evt =>
    dropZone.addEventListener(evt, e => {
      e.preventDefault();
      dropZone.classList.remove("drag-over");
    })
  );

  dropZone.addEventListener("drop", e => {
    const files = e.dataTransfer?.files;
    if (files && files.length) {
      fileInput.files = files;
      handleFileSelect(files[0]);
    }
  });

  // ── Keyboard accessibility ────────────────────────────────────
  dropZone.addEventListener("keydown", e => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      fileInput.click();
    }
  });

  // ── File input change ─────────────────────────────────────────
  fileInput.addEventListener("change", () => {
    if (fileInput.files.length) {
      handleFileSelect(fileInput.files[0]);
    }
  });

  // ── Clear selection ───────────────────────────────────────────
  if (clearBtn) {
    clearBtn.addEventListener("click", () => {
      fileInput.value = "";
      previewImg.src  = "";
      previewArea.classList.add("hidden");
    });
  }

  // ── Form submission with progress ────────────────────────────
  if (form) {
    form.addEventListener("submit", () => {
      if (!fileInput.files.length) return;   // let native validation handle it
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.textContent = "⚙️ Processing …";
      }
      if (progressWrap) progressWrap.classList.remove("hidden");
    });
  }

  // ── Helper: read file and show preview ───────────────────────
  function handleFileSelect(file) {
    if (!file) return;

    // Basic client-side type check
    const allowed = ["image/jpeg", "image/png", "image/bmp", "image/webp"];
    if (!allowed.includes(file.type)) {
      showToast("Please select a valid image file (JPG, PNG, BMP, WEBP).", "error");
      return;
    }

    // Max size check: 5 MB
    if (file.size > 5 * 1024 * 1024) {
      showToast("File exceeds 5 MB limit.", "error");
      return;
    }

    const reader = new FileReader();
    reader.onload = e => {
      previewImg.src = e.target.result;
      if (fileNameEl)  fileNameEl.textContent = file.name;
      if (previewArea) previewArea.classList.remove("hidden");
    };
    reader.readAsDataURL(file);
  }

  // ── Toast notification (lightweight) ─────────────────────────
  function showToast(msg, type = "info") {
    const toast = document.createElement("div");
    toast.className = `flash flash--${type}`;
    toast.style.cssText = "position:fixed;top:80px;right:20px;z-index:9999;max-width:360px;animation:fadeSlide 0.3s ease";
    toast.textContent = msg;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 4000);
  }

  // ── Inject keyframe for toast ─────────────────────────────────
  const style = document.createElement("style");
  style.textContent = `
    @keyframes fadeSlide {
      from { opacity:0; transform:translateY(-12px); }
      to   { opacity:1; transform:translateY(0); }
    }
  `;
  document.head.appendChild(style);

})();
