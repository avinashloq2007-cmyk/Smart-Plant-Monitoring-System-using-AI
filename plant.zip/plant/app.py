"""
app.py
======
Flask web application for Plant Disease Detection and Fertilizer Suggestion.

Routes:
  GET  /              → Upload form (index.html)
  POST /predict       → Upload image → HTML result page
  POST /api/predict   → REST API → JSON response
  GET  /charts        → Shows model comparison charts page

Error handling:
  - Invalid file extension
  - File too large (>5 MB)
  - Corrupt or unreadable image
  - Model not trained yet
"""

import os
import io
import pickle
import uuid

import cv2
import numpy as np
from flask import (Flask, request, render_template,
                   jsonify, redirect, url_for, flash)
from werkzeug.utils import secure_filename
from PIL import Image

from utils.feature_extractor import load_and_preprocess, extract_features


# ─── App Configuration ────────────────────────────────────────────────────────
app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "plant-disease-secret-2024")

BASE_DIR       = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR      = os.path.join(BASE_DIR, "model")
UPLOAD_FOLDER  = os.path.join(BASE_DIR, "static", "uploads")
CHARTS_DIR     = os.path.join(BASE_DIR, "static", "charts")

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(CHARTS_DIR,    exist_ok=True)

app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024   # 5 MB limit

ALLOWED_EXTENSIONS = {"jpg", "jpeg", "png", "bmp", "webp"}


# ─── Fertilizer Recommendation Map ───────────────────────────────────────────
FERTILIZER_MAP = {
    "Healthy":      {
        "name":        "Balanced Fertilizer (NPK 10-10-10)",
        "description": "Your plant is healthy! Apply a balanced NPK fertilizer "
                       "to maintain optimal growth and resilience.",
        "icon":        "🌿",
        "color":       "#27ae60",
    },
    "Early_Blight": {
        "name":        "High Nitrogen Fertilizer (NPK 30-10-10)",
        "description": "Early Blight detected. Boost plant immunity with a "
                       "high-nitrogen fertilizer and remove affected leaves.",
        "icon":        "⚠️",
        "color":       "#f39c12",
    },
    "Late_Blight":  {
        "name":        "Potassium-rich Fertilizer (NPK 5-10-20)",
        "description": "Late Blight detected. Apply potassium-rich fertilizer "
                       "and a copper-based fungicide. Remove infected material.",
        "icon":        "🚨",
        "color":       "#e74c3c",
    },
}


# ─── Load ML Artifacts ────────────────────────────────────────────────────────

def load_model():
    """Load model, scaler, and label encoder from disk. Returns (model, scaler, le) or None."""
    paths = {
        "model":   os.path.join(MODEL_DIR, "best_model.pkl"),
        "scaler":  os.path.join(MODEL_DIR, "scaler.pkl"),
        "encoder": os.path.join(MODEL_DIR, "label_encoder.pkl"),
    }
    for key, path in paths.items():
        if not os.path.exists(path):
            return None, None, None

    with open(paths["model"],   "rb") as f: model   = pickle.load(f)
    with open(paths["scaler"],  "rb") as f: scaler  = pickle.load(f)
    with open(paths["encoder"], "rb") as f: encoder = pickle.load(f)
    return model, scaler, encoder


# Load once at startup
model, scaler, label_encoder = load_model()


# ─── Helper Functions ─────────────────────────────────────────────────────────

def allowed_file(filename: str) -> bool:
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def validate_image(file_bytes: bytes) -> bool:
    """Verify the bytes can be decoded as an image by OpenCV."""
    arr = np.frombuffer(file_bytes, np.uint8)
    img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    return img is not None


def calculate_disease_severity(img_bgr: np.ndarray) -> float:
    """Calculate the percentage of the leaf area that is diseased (non-green)."""
    # Resize to a consistent size for speed
    img_small = cv2.resize(img_bgr, (256, 256), interpolation=cv2.INTER_AREA)
    
    gray = cv2.cvtColor(img_small, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (5, 5), 0)
    
    # Mask out the background
    _, leaf_mask = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    
    total_leaf_pixels = cv2.countNonZero(leaf_mask)
    if total_leaf_pixels == 0:
        return 0.0
        
    hsv = cv2.cvtColor(img_small, cv2.COLOR_BGR2HSV)
    
    # Define range for healthy green leaf colors
    lower_green = np.array([25, 40, 40])
    upper_green = np.array([95, 255, 255])
    green_mask = cv2.inRange(hsv, lower_green, upper_green)
    
    # intersection: green pixels that are inside the leaf
    healthy_pixels = cv2.countNonZero(cv2.bitwise_and(green_mask, leaf_mask))
    
    diseased_pixels = max(0, total_leaf_pixels - healthy_pixels)
    severity = diseased_pixels / float(total_leaf_pixels)
    
    return min(1.0, max(0.0, severity))


def predict_from_bytes(file_bytes: bytes):
    """
    Run the full prediction pipeline on raw image bytes.

    Returns:
        predicted_class (str), confidence (float 0-1), fertilizer_info (dict)

    Raises:
        ValueError on invalid image or untrained model.
    """
    if model is None:
        raise ValueError("Model not found. Please run 'python train_model.py' first.")

    # Decode image with OpenCV
    arr = np.frombuffer(file_bytes, np.uint8)
    img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError("Could not decode image. Ensure it is a valid image file.")

    img_resized = cv2.resize(img, (64, 64), interpolation=cv2.INTER_AREA)

    # Extract features → scale → predict
    features = extract_features(img_resized).reshape(1, -1)
    features_scaled = scaler.transform(features)

    pred_class  = model.predict(features_scaled)[0]
    proba       = model.predict_proba(features_scaled)[0]
    confidence  = float(max(proba))

    # The model was trained with string labels (via le.inverse_transform
    # in train_model.py), so pred_class is already a string like "Healthy".
    # If it were an int, decode it; otherwise use as-is.
    if isinstance(pred_class, (int, np.integer)):
        pred_class = label_encoder.inverse_transform([pred_class])[0]

    # Get base fertilizer template
    base_fert_info = FERTILIZER_MAP.get(pred_class, {
        "name":        "General Purpose Fertilizer",
        "description": "Apply a general-purpose fertilizer and monitor closely.",
        "icon":        "🌱",
        "color":       "#3498db",
    })
    
    # Create a mutable copy
    fertilizer = dict(base_fert_info)
    
    # Tailor recommendation based on computational severity
    severity = calculate_disease_severity(img)
    severity_pct = int(severity * 100)
    
    if pred_class == "Healthy":
        fertilizer["description"] = (
            f"Your plant leaf is highly healthy (only ~{severity_pct}% surface blemishes detected). "
            f"Apply your {fertilizer['name']} preventatively to maintain optimal growth!"
        )
    else:
        # Dynamic tailoring based on visual severity
        formatted_name = pred_class.replace('_', ' ')
        if severity_pct < 20:
            dose = "Apply a half-strength dose of"
            action = "Monitor closely and gently prune the few affected spots."
        elif severity_pct < 60:
            dose = "Apply a standard full-strength dose of"
            action = "Remove the visibly affected leaves."
        else:
            dose = "Use an intensive fungicide treatment layered with"
            action = "Infection is severe (>60% structural damage). Consider removing this leaf entirely to prevent spread."
            
        fertilizer["description"] = (
            f"Detected {formatted_name}. The leaf shows approximately {severity_pct}% diseased surface area. "
            f"{action} {dose} {fertilizer['name']}."
        )

    return pred_class, confidence, fertilizer


# ─── Routes ───────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    """Upload form page."""
    model_ready = model is not None
    return render_template("index.html", model_ready=model_ready)


@app.route("/predict", methods=["POST"])
def predict():
    """Handle image upload from HTML form → redirect to result page."""
    if "file" not in request.files:
        flash("No file selected.", "error")
        return redirect(url_for("index"))

    file = request.files["file"]
    if file.filename == "":
        flash("No file selected.", "error")
        return redirect(url_for("index"))

    if not allowed_file(file.filename):
        flash(f"Invalid file type. Allowed: {', '.join(ALLOWED_EXTENSIONS)}", "error")
        return redirect(url_for("index"))

    file_bytes = file.read()

    if not validate_image(file_bytes):
        flash("File does not appear to be a valid image.", "error")
        return redirect(url_for("index"))

    # Save uploaded file with a unique name
    ext       = secure_filename(file.filename).rsplit(".", 1)[-1]
    uid       = uuid.uuid4().hex[:8]
    save_name = f"upload_{uid}.{ext}"
    save_path = os.path.join(UPLOAD_FOLDER, save_name)
    with open(save_path, "wb") as f:
        f.write(file_bytes)

    try:
        pred_class, confidence, fertilizer = predict_from_bytes(file_bytes)
    except ValueError as e:
        flash(str(e), "error")
        return redirect(url_for("index"))

    return render_template(
        "result.html",
        prediction   = pred_class,
        confidence   = round(confidence * 100, 2),
        fertilizer   = fertilizer,
        image_url    = url_for("static", filename=f"uploads/{save_name}"),
        original_name = secure_filename(file.filename),
    )


@app.route("/api/predict", methods=["POST"])
def api_predict():
    """
    REST API endpoint for programmatic access.

    Request (multipart/form-data):
      file : image file

    Response (JSON):
      {
        "success": true,
        "class": "...",
        "confidence": 0.95,
        "fertilizer": {
          "name": "...",
          "description": "...",
          "icon": "...",
          "color": "..."
        }
      }
    """
    if "file" not in request.files:
        return jsonify({"success": False, "error": "No file provided"}), 400

    file = request.files["file"]
    if not allowed_file(file.filename):
        return jsonify({"success": False,
                        "error": f"Invalid extension. Allowed: {ALLOWED_EXTENSIONS}"}), 400

    file_bytes = file.read()
    if not validate_image(file_bytes):
        return jsonify({"success": False, "error": "Cannot decode image"}), 400

    try:
        pred_class, confidence, fertilizer = predict_from_bytes(file_bytes)
    except ValueError as e:
        return jsonify({"success": False, "error": str(e)}), 500

    return jsonify({
        "success":    True,
        "class":      pred_class,
        "confidence": round(confidence, 4),
        "fertilizer": fertilizer,
    })


@app.route("/charts")
def charts():
    """Page showing model comparison charts."""
    chart_files = [f for f in os.listdir(CHARTS_DIR) if f.endswith(".png")]
    chart_urls  = [url_for("static", filename=f"charts/{f}") for f in sorted(chart_files)]
    return render_template("charts.html", chart_urls=chart_urls)


@app.errorhandler(413)
def file_too_large(e):
    flash("File is too large. Maximum size is 5 MB.", "error")
    return redirect(url_for("index"))


# ─── Entry Point ──────────────────────────────────────────────────────────────

if __name__ == "__main__":
    if model is None:
        print("[WARNING] Model not found. Run 'python train_model.py' first.\n")
    else:
        print("[OK] Model loaded successfully.\n")

    print("Starting Flask server on http://localhost:5000 ...\n")
    app.run(debug=True, host="0.0.0.0", port=5000)
